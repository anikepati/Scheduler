"""CLI: run / discover / govern / api / metrics"""
import asyncio, argparse, json, logging, sys
sys.path.insert(0, ".")
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai.types import Content, Part
from framework.agent import SelfLearningAgent
from framework.background import PatternDiscoveryAgent, GovernanceAgent
from framework import db
from domains.edr_qa import create_config

logging.basicConfig(level=logging.INFO, format="%(name)s: %(message)s")
APP = "ace_v4"

QS = [
    {"id":"Q01","type":"wire_alert","text":"Wire $45K, 2 prior wires, beneficiary NOT approved. Alert?",
     "data":{"amount":45000,"prior_wires":2,"beneficiary_approved":False},
     "facts":["$50K threshold","90-day lookback","prior wires","beneficiary","AND logic"],
     "truth":"No. $45K below $50K. AND logic requires all three."},
    {"id":"Q02","type":"ctr_aggregation","text":"3 deposits ($4K+$3.5K+$3.8K=$11.3K) rolling 24hr midnight. CTR?",
     "data":{"amounts":[4000,3500,3800],"total":11300,"window":"rolling midnight"},
     "facts":["rolling 24-hour","$10K threshold","midnight structuring"],
     "truth":"Yes. $11.3K exceeds $10K. Rolling 24hr catches midnight."},
    {"id":"Q03","type":"pep_screening","text":"PEP fuzzy 0.83, exact surname match. Expected?",
     "data":{"score":0.83,"exact_surname":True},
     "facts":["0.85 threshold","below threshold","surname-override exception"],
     "truth":"Below 0.85 BUT surname-override. Escalate."},
]

async def run_qa(cfg, rounds):
    agent = SelfLearningAgent(name="Learner", config=cfg)
    ss = InMemorySessionService()
    runner = Runner(agent=agent, app_name=APP, session_service=ss)
    for r in range(1, rounds+1):
        print(f"\n{'='*60}\n  ROUND {r}\n{'='*60}")
        for q in QS:
            s = await ss.create_session(app_name=APP, user_id="qa", state={
                "question_id":q["id"],"question_type":q["type"],"user_question":q["text"],
                "question_data":json.dumps(q["data"]),"key_facts":json.dumps(q["facts"])})
            async for ev in runner.run_async(user_id="qa", session_id=s.id,
                    new_message=Content(role="user", parts=[Part(text=q["text"])])):
                if ev.is_final_response() and ev.content:
                    print(f"\n  {q['id']}: {ev.content.parts[0].text[:250]}...")
        m = await db.get_metrics(cfg.use_case_id)
        print(f"\n  score={m['avg_score']}% auto={m['automation_pct']}% followed={m['harness_followed_pct']}% validators={m['validators']} trees={m['tree_rules']}")

async def run_bg(cfg, name):
    agents = {"discover": PatternDiscoveryAgent, "govern": GovernanceAgent}
    agent = agents[name](name=name, config=cfg)
    ss = InMemorySessionService()
    runner = Runner(agent=agent, app_name=f"{APP}_{name}", session_service=ss)
    s = await ss.create_session(app_name=f"{APP}_{name}", user_id="sys", state={})
    async for ev in runner.run_async(user_id="sys", session_id=s.id,
            new_message=Content(role="user", parts=[Part(text="run")])):
        if ev.is_final_response() and ev.content: print(ev.content.parts[0].text)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("cmd", choices=["run","discover","govern","api","metrics"])
    p.add_argument("--rounds", type=int, default=1)
    p.add_argument("--db", default="postgresql://localhost:5432/ace_learning")
    a = p.parse_args()
    cfg = create_config(a.db)
    if a.cmd == "run": asyncio.run(run_qa(cfg, a.rounds))
    elif a.cmd in ("discover","govern"): asyncio.run(run_bg(cfg, a.cmd))
    elif a.cmd == "api":
        import uvicorn; from api import create_app; uvicorn.run(create_app(cfg), host="0.0.0.0", port=8001)
    elif a.cmd == "metrics":
        async def show():
            await db.init_pool(cfg.db_url); await db.init_tables()
            m = await db.get_metrics(cfg.use_case_id)
            for k,v in m.items(): print(f"  {k}: {v}")
        asyncio.run(show())

if __name__ == "__main__": main()
