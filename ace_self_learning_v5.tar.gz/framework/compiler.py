"""Compiler Agent — transforms corrections into tree + validator + strategy.
Paper insight: evolver model can be CHEAP (harness-updating is flat in capability)."""
import json, logging
from google.genai import Client as GenaiClient
from google.genai import types as genai_types
from framework.models import ValidatorRule, TreeRule, ReasoningStrategy
from framework import db

logger = logging.getLogger(__name__)
_uid = lambda: str(__import__('uuid').uuid4())

async def compile_correction(uc_id, qtype, chain, evolver_model="gemini-2.0-flash"):
    """One correction → three structural outputs. Uses CHEAP evolver model (paper finding #1)."""
    correction = chain.get("user_correction","")
    if not correction: return

    qdata = chain.get("question_data",{})
    if isinstance(qdata, str): qdata = json.loads(qdata)
    reasoning = chain.get("reasoning_chain",[])
    if isinstance(reasoning, str): reasoning = json.loads(reasoning)
    target = chain.get("correction_target_step","")

    prompt = f"""Analyze this correction and extract structural rules.
QUESTION: {chain.get('question_text','')}
DATA: {json.dumps(qdata)[:300]}
REASONING: {json.dumps(reasoning)[:400]}
CORRECTION: {correction}
TARGET STEP: {target}

Output JSON:
{{"tree_rule":{{"condition":"<python expr with data.field>","conclusion":"<answer>","rationale_template":"<with ${{data.field}}>","confidence":<0-1>}},
"validator":{{"step_id":"<step>","check_type":"fact|logic|reasoning","must_contain":["<keywords>"],"condition":"<when applies>","confidence":<0-1>}},
"strategy_update":{{"thinking_step":"<new approach step>","error_to_avoid":{{"error":"<what went wrong>","fix":"<how to fix>"}},"good_example":{{"reasoning":"<correct reasoning>"}}}}}}"""

    try:
        r = GenaiClient().models.generate_content(model=evolver_model, contents=prompt,
            config=genai_types.GenerateContentConfig(temperature=0.1, max_output_tokens=800))
        t = r.text.strip()
        if t.startswith("```"): t = t.split("\n",1)[1].rsplit("```",1)[0].strip()
        result = json.loads(t)

        # Target 1: tree rule
        tr = result.get("tree_rule",{})
        if tr.get("condition") and tr.get("conclusion"):
            await db.save_tree_rule(uc_id, qtype, TreeRule(id=_uid(), condition=tr["condition"],
                conclusion=tr["conclusion"], rationale_template=tr.get("rationale_template",""),
                confidence=tr.get("confidence",0.5)))

        # Target 2: validator
        vr = result.get("validator",{})
        if vr.get("check_type") and vr.get("must_contain"):
            await db.save_validator(uc_id, qtype, ValidatorRule(id=_uid(), step_id=vr.get("step_id",""),
                check_type=vr["check_type"], condition=vr.get("condition",""),
                must_contain=vr.get("must_contain",[]), confidence=vr.get("confidence",0.5)))

        # Target 3: strategy update
        su = result.get("strategy_update",{})
        existing = await db.get_strategy(uc_id, qtype)
        strat = _merge(existing, su, chain)
        await db.save_strategy(uc_id, qtype, strat)

        await db.log_event(uc_id, "compiler", chain.get("id",""), "compiled", "tree+validator+strategy")
    except Exception as e:
        logger.error(f"Compile error: {e}")

def _merge(existing, update, chain):
    if existing:
        steps = json.loads(existing["thinking_steps"]) if isinstance(existing.get("thinking_steps"), str) else existing.get("thinking_steps",[])
        errors = json.loads(existing["errors_to_avoid"]) if isinstance(existing.get("errors_to_avoid"), str) else existing.get("errors_to_avoid",[])
        examples = json.loads(existing["good_examples"]) if isinstance(existing.get("good_examples"), str) else existing.get("good_examples",[])
        count = existing.get("compiled_from_count",0)
    else:
        steps, errors, examples, count = [], [], [], 0

    ns = update.get("thinking_step","")
    if ns and ns not in steps:
        steps.append(ns)
        if len(steps) > 10: steps = steps[-10:]

    err = update.get("error_to_avoid",{})
    if err.get("error"):
        found = False
        for e in errors:
            if e.get("error","").lower() == err["error"].lower():
                e["frequency"] = e.get("frequency",1) + 1; found = True; break
        if not found: errors.append({"error":err["error"],"fix":err.get("fix",""),"frequency":1})
        if len(errors) > 8: errors = sorted(errors, key=lambda x: x.get("frequency",0), reverse=True)[:8]

    ex = update.get("good_example",{})
    if ex.get("reasoning"):
        examples.append({"question": chain.get("question_text","")[:100], "reasoning": ex["reasoning"][:300]})
        if len(examples) > 5: examples = examples[-5:]

    return ReasoningStrategy(question_type=chain.get("question_type",""), thinking_steps=steps,
        errors_to_avoid=errors, good_examples=examples, compiled_from_count=count+1)
