"""PostgreSQL — chains, tree_rules, validators, reasoning_strategies, patterns, events."""
import json, logging
from typing import Optional
import asyncpg
from framework.models import ChainRecord, Pattern

logger = logging.getLogger(__name__)
_pool = None

async def init_pool(url):
    global _pool
    if not _pool: _pool = await asyncpg.create_pool(url, min_size=2, max_size=20)

async def pool():
    if not _pool: raise RuntimeError("init_pool first")
    return _pool

async def init_tables():
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""
        CREATE TABLE IF NOT EXISTS chains (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL, question_type TEXT NOT NULL,
            question_text TEXT NOT NULL, question_data JSONB DEFAULT '{}',
            reasoning_chain JSONB DEFAULT '[]', answer TEXT DEFAULT '',
            rationale TEXT DEFAULT '', score INT DEFAULT 0,
            covered JSONB DEFAULT '[]', missed JSONB DEFAULT '[]',
            layer TEXT DEFAULT 'L3', activated_harness JSONB DEFAULT '[]',
            harness_followed BOOLEAN DEFAULT FALSE,
            validator_results JSONB DEFAULT '[]',
            user_action TEXT, user_correction TEXT DEFAULT '',
            correction_target_step TEXT DEFAULT '',
            cluster_id TEXT, created_at TIMESTAMPTZ DEFAULT now());
        CREATE INDEX IF NOT EXISTS ix_ch_uc ON chains(use_case_id, question_type);
        CREATE INDEX IF NOT EXISTS ix_ch_corr ON chains(use_case_id) WHERE user_action='correct';
        CREATE INDEX IF NOT EXISTS ix_ch_score ON chains(use_case_id, score DESC);

        CREATE TABLE IF NOT EXISTS reasoning_strategies (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL,
            question_type TEXT NOT NULL UNIQUE, version INT DEFAULT 1,
            thinking_steps JSONB DEFAULT '[]', errors_to_avoid JSONB DEFAULT '[]',
            good_examples JSONB DEFAULT '[]', constraints JSONB DEFAULT '[]',
            compiled_from_count INT DEFAULT 0, updated_at TIMESTAMPTZ DEFAULT now());

        CREATE TABLE IF NOT EXISTS validator_rules (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL, question_type TEXT NOT NULL,
            step_id TEXT DEFAULT '', check_type TEXT NOT NULL, condition TEXT DEFAULT '',
            expected JSONB, must_contain JSONB DEFAULT '[]',
            confidence REAL DEFAULT 0.5, active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT now());
        CREATE INDEX IF NOT EXISTS ix_vr ON validator_rules(use_case_id, question_type) WHERE active;

        CREATE TABLE IF NOT EXISTS tree_rules (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL, question_type TEXT NOT NULL,
            condition TEXT NOT NULL, conclusion TEXT NOT NULL,
            rationale_template TEXT DEFAULT '', confidence REAL DEFAULT 0.0,
            edge_cases JSONB DEFAULT '[]', priority INT DEFAULT 0, active BOOLEAN DEFAULT TRUE,
            created_at TIMESTAMPTZ DEFAULT now());
        CREATE INDEX IF NOT EXISTS ix_tr ON tree_rules(use_case_id, question_type) WHERE active;

        CREATE TABLE IF NOT EXISTS clusters (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL, question_type TEXT DEFAULT '',
            member_count INT DEFAULT 0, correction_count INT DEFAULT 0,
            last_analyzed_at TIMESTAMPTZ, created_at TIMESTAMPTZ DEFAULT now());

        CREATE TABLE IF NOT EXISTS patterns (
            id TEXT PRIMARY KEY, use_case_id TEXT NOT NULL, cluster_id TEXT DEFAULT '',
            description TEXT NOT NULL, evidence_count INT DEFAULT 0,
            status TEXT DEFAULT 'candidate', ab_treatment JSONB DEFAULT '[]',
            ab_control JSONB DEFAULT '[]', created_at TIMESTAMPTZ DEFAULT now());

        CREATE TABLE IF NOT EXISTS events (
            id BIGSERIAL PRIMARY KEY, use_case_id TEXT, entity_type TEXT,
            entity_id TEXT, event TEXT, detail TEXT DEFAULT '',
            created_at TIMESTAMPTZ DEFAULT now());
        """)

# Chain ops
async def save_chain(ch):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""INSERT INTO chains (id,use_case_id,question_type,question_text,question_data,
            reasoning_chain,answer,rationale,score,covered,missed,layer,activated_harness,
            harness_followed,validator_results,cluster_id,created_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)""",
            ch.id, ch.use_case_id, ch.question_type, ch.question_text,
            json.dumps(ch.question_data), json.dumps([s.model_dump() for s in ch.reasoning_chain]),
            ch.answer, ch.rationale, ch.score, json.dumps(ch.covered), json.dumps(ch.missed),
            ch.layer, json.dumps(ch.activated_harness), ch.harness_followed,
            json.dumps(ch.validator_results), ch.cluster_id, ch.created_at)

async def get_chain(cid):
    p = await pool()
    async with p.acquire() as c:
        r = await c.fetchrow("SELECT * FROM chains WHERE id=$1", cid)
    return dict(r) if r else None

async def update_feedback(cid, action, correction, step=""):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("UPDATE chains SET user_action=$1,user_correction=$2,correction_target_step=$3 WHERE id=$4",
            action, correction, step, cid)

async def get_previous_corrections(uc_id, qtype, limit=5):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("""SELECT reasoning_chain, user_correction, correction_target_step, score
            FROM chains WHERE use_case_id=$1 AND question_type=$2 AND user_action='correct'
            ORDER BY created_at DESC LIMIT $3""", uc_id, qtype, limit)
    return [dict(r) for r in rows]

async def count_chains(uc_id):
    p = await pool()
    async with p.acquire() as c:
        return await c.fetchval("SELECT COUNT(*) FROM chains WHERE use_case_id=$1", uc_id)

# Strategy ops
async def get_strategy(uc_id, qtype):
    p = await pool()
    async with p.acquire() as c:
        r = await c.fetchrow("SELECT * FROM reasoning_strategies WHERE use_case_id=$1 AND question_type=$2", uc_id, qtype)
    return dict(r) if r else None

async def save_strategy(uc_id, qtype, strat):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""INSERT INTO reasoning_strategies (id,use_case_id,question_type,thinking_steps,
            errors_to_avoid,good_examples,constraints,compiled_from_count,updated_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,now())
            ON CONFLICT(question_type) DO UPDATE SET thinking_steps=EXCLUDED.thinking_steps,
                errors_to_avoid=EXCLUDED.errors_to_avoid, good_examples=EXCLUDED.good_examples,
                constraints=EXCLUDED.constraints, compiled_from_count=EXCLUDED.compiled_from_count,
                version=reasoning_strategies.version+1, updated_at=now()""",
            str(__import__('uuid').uuid4()), uc_id, qtype,
            json.dumps(strat.thinking_steps), json.dumps(strat.errors_to_avoid),
            json.dumps(strat.good_examples), json.dumps(strat.constraints), strat.compiled_from_count)

# Validator ops
async def get_validators(uc_id, qtype):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("SELECT * FROM validator_rules WHERE use_case_id=$1 AND question_type=$2 AND active ORDER BY confidence DESC", uc_id, qtype)
    return [dict(r) for r in rows]

async def save_validator(uc_id, qtype, v):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""INSERT INTO validator_rules (id,use_case_id,question_type,step_id,check_type,condition,expected,must_contain,confidence)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) ON CONFLICT(id) DO UPDATE SET confidence=EXCLUDED.confidence, must_contain=EXCLUDED.must_contain""",
            v.id, uc_id, qtype, v.step_id, v.check_type, v.condition,
            json.dumps(v.expected), json.dumps(v.must_contain), v.confidence)

# Tree ops
async def get_tree_rules(uc_id, qtype):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("SELECT * FROM tree_rules WHERE use_case_id=$1 AND question_type=$2 AND active ORDER BY priority DESC, confidence DESC", uc_id, qtype)
    return [dict(r) for r in rows]

async def save_tree_rule(uc_id, qtype, rule):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""INSERT INTO tree_rules (id,use_case_id,question_type,condition,conclusion,rationale_template,confidence,edge_cases)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8) ON CONFLICT(id) DO UPDATE SET confidence=EXCLUDED.confidence""",
            rule.id, uc_id, qtype, rule.condition, rule.conclusion,
            rule.rationale_template, rule.confidence, json.dumps(rule.edge_cases))

# Cluster ops
async def upsert_cluster(cid, uc_id, qtype, count, corrections):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("""INSERT INTO clusters (id,use_case_id,question_type,member_count,correction_count)
            VALUES ($1,$2,$3,$4,$5) ON CONFLICT(id) DO UPDATE SET member_count=$4,correction_count=$5""",
            cid, uc_id, qtype, count, corrections)

async def get_cluster_corrections(cid, limit=20):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("""SELECT question_text, user_correction, correction_target_step, reasoning_chain, score
            FROM chains WHERE cluster_id=$1 AND user_action='correct' ORDER BY created_at DESC LIMIT $2""", cid, limit)
    return [dict(r) for r in rows]

async def get_clusters_for_discovery(uc_id, min_corr=3):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("""SELECT id, question_type, member_count, correction_count
            FROM clusters WHERE use_case_id=$1 AND correction_count >= $2
            AND (last_analyzed_at IS NULL OR correction_count > (SELECT COUNT(*) FROM patterns WHERE cluster_id=clusters.id) + $2)
            ORDER BY correction_count DESC LIMIT 10""", uc_id, min_corr)
    return [dict(r) for r in rows]

async def mark_analyzed(cid):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("UPDATE clusters SET last_analyzed_at=now() WHERE id=$1", cid)

# Pattern ops
async def save_pattern(pat):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("INSERT INTO patterns (id,use_case_id,cluster_id,description,evidence_count,status) VALUES ($1,$2,$3,$4,$5,$6)",
            pat.id, pat.use_case_id, pat.cluster_id, pat.description, pat.evidence_count, pat.status.value)

async def get_probation_patterns(uc_id):
    p = await pool()
    async with p.acquire() as c:
        rows = await c.fetch("SELECT * FROM patterns WHERE use_case_id=$1 AND status='probation'", uc_id)
    return [dict(r) for r in rows]

async def set_pattern_status(pid, uc_id, status, reason=""):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("UPDATE patterns SET status=$1 WHERE id=$2", status, pid)
        await c.execute("INSERT INTO events (use_case_id,entity_type,entity_id,event,detail) VALUES ($1,'pattern',$2,$3,$4)", uc_id, pid, status, reason)

async def append_ab(pid, score, treatment):
    col = "ab_treatment" if treatment else "ab_control"
    p = await pool()
    async with p.acquire() as c:
        await c.execute(f"UPDATE patterns SET {col}={col}||$1::jsonb WHERE id=$2", json.dumps([score]), pid)

async def log_event(uc_id, etype, eid, event, detail=""):
    p = await pool()
    async with p.acquire() as c:
        await c.execute("INSERT INTO events (use_case_id,entity_type,entity_id,event,detail) VALUES ($1,$2,$3,$4,$5)", uc_id, etype, eid, event, detail)

async def get_metrics(uc_id):
    p = await pool()
    async with p.acquire() as c:
        total = await c.fetchval("SELECT COUNT(*) FROM chains WHERE use_case_id=$1", uc_id)
        avg = await c.fetchval("SELECT COALESCE(AVG(score),0) FROM chains WHERE use_case_id=$1", uc_id)
        corr = await c.fetchval("SELECT COUNT(*) FROM chains WHERE use_case_id=$1 AND user_action='correct'", uc_id)
        l1 = await c.fetchval("SELECT COUNT(*) FROM chains WHERE use_case_id=$1 AND layer='L1'", uc_id)
        followed = await c.fetchval("SELECT COUNT(*) FROM chains WHERE use_case_id=$1 AND harness_followed", uc_id)
        vals = await c.fetchval("SELECT COUNT(*) FROM validator_rules WHERE use_case_id=$1 AND active", uc_id)
        strats = await c.fetchval("SELECT COUNT(*) FROM reasoning_strategies WHERE use_case_id=$1", uc_id)
        trees = await c.fetchval("SELECT COUNT(*) FROM tree_rules WHERE use_case_id=$1 AND active", uc_id)
    return {"chains": total, "avg_score": round(float(avg),1), "corrections": corr,
            "auto_approved_L1": l1, "harness_followed_pct": round(followed/max(1,total)*100,1),
            "validators": vals, "strategies": strats, "tree_rules": trees,
            "automation_pct": round(l1/max(1,total)*100,1)}
