"""Validate reasoning chain steps against compiled rules."""
import json, logging
from framework.models import ValidatorRule
from framework import db

logger = logging.getLogger(__name__)

class ValidationResult:
    def __init__(self, vid, passed, msg="", conf=0.0):
        self.validator_id = vid; self.passed = passed; self.message = msg; self.confidence = conf
    def to_dict(self): return {"validator_id": self.validator_id, "passed": self.passed, "message": self.message, "confidence": self.confidence}

async def run_validators(uc_id, qtype, qdata, chain, answer):
    rules = await db.get_validators(uc_id, qtype)
    return [_eval(r, qdata, chain, answer) for r in rules]

def _eval(rule, data, chain, answer):
    vid, cond = rule["id"], rule.get("condition","")
    if cond:
        try:
            if not eval(cond, {"data": data, "__builtins__": {}}):
                return ValidationResult(vid, True, "N/A", 1.0)
        except: return ValidationResult(vid, True, "cond error", 0.0)

    mc = rule.get("must_contain")
    if isinstance(mc, str): mc = json.loads(mc)
    mc = mc or []
    ct = rule.get("check_type","fact")
    low = answer.lower()

    if ct == "fact":
        missing = [m for m in mc if m.lower() not in low]
        return ValidationResult(vid, not missing, f"Missing: {', '.join(missing)}" if missing else "OK", rule.get("confidence",0.5))
    elif ct == "logic":
        sid, exp = rule.get("step_id",""), rule.get("expected")
        if isinstance(exp, str):
            try: exp = json.loads(exp)
            except: pass
        if sid and exp is not None:
            for s in chain:
                s_id = s.get("step_id","") if isinstance(s, dict) else s.step_id
                if s_id == sid:
                    conc = s.get("conclusion","") if isinstance(s, dict) else s.conclusion
                    if str(conc).lower() != str(exp).lower():
                        return ValidationResult(vid, False, f"{sid}: expected {exp}, got {conc}", rule.get("confidence",0.5))
        return ValidationResult(vid, True, "Logic OK", rule.get("confidence",0.5))
    elif ct == "reasoning":
        all_r = " ".join((s.get("reasoning","") if isinstance(s,dict) else s.reasoning) for s in chain).lower()
        combined = low + " " + all_r
        missing = [m for m in mc if m.lower() not in combined]
        return ValidationResult(vid, not missing, f"Reasoning missing: {', '.join(missing)}" if missing else "OK", rule.get("confidence",0.5))
    return ValidationResult(vid, True, "Unknown", 0.0)

def all_pass(results, threshold=0.95):
    return bool(results) and all(r.passed for r in results) and min(r.confidence for r in results) >= threshold

def get_constraints(results):
    return [f"CONSTRAINT: {r.message}" for r in results if not r.passed]
