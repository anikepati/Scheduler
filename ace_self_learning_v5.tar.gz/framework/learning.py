"""Feedback processing → triggers compilation."""
import json, hashlib, logging
from framework.models import ChainRecord
from framework.compiler import compile_correction
from framework import db

logger = logging.getLogger(__name__)

def cluster_id(uc_id, qtype):
    return hashlib.sha256(f"{uc_id}:{qtype}".encode()).hexdigest()[:16]

async def assign_cluster(chain):
    cid = cluster_id(chain.use_case_id, chain.question_type)
    p = await db.pool()
    async with p.acquire() as c:
        await c.execute("UPDATE chains SET cluster_id=$1 WHERE id=$2", cid, chain.id)
        counts = await c.fetchrow("SELECT COUNT(*) as t, COUNT(*) FILTER (WHERE user_action='correct') as c FROM chains WHERE cluster_id=$1", cid)
    await db.upsert_cluster(cid, chain.use_case_id, chain.question_type, counts["t"], counts["c"])

async def process_feedback(chain_id, action, correction, target_step, uc_id, evolver_model="gemini-2.0-flash"):
    await db.update_feedback(chain_id, action, correction, target_step)
    chain = await db.get_chain(chain_id)
    if not chain: return
    cid = chain.get("cluster_id")
    if cid:
        p = await db.pool()
        async with p.acquire() as c:
            corr = await c.fetchval("SELECT COUNT(*) FROM chains WHERE cluster_id=$1 AND user_action='correct'", cid)
            await c.execute("UPDATE clusters SET correction_count=$1 WHERE id=$2", corr, cid)
    if action == "correct" and correction.strip():
        await compile_correction(uc_id, chain.get("question_type",""), chain, evolver_model)
    await db.log_event(uc_id, "feedback", chain_id, f"feedback_{action}", (correction or "")[:100])
