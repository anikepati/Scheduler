"""Domain configuration.
Paper insight: use cheap model for evolver, strong model for solver."""
from dataclasses import dataclass, field

@dataclass
class DomainConfig:
    use_case_id: str
    name: str
    system_instruction: str = "You are an expert analyst."
    db_url: str = "postgresql://localhost:5432/ace_learning"
    # Paper finding: invest capability in task-solver, not evolver
    solver_model: str = "gemini-2.5-flash"     # strong model for answering
    evolver_model: str = "gemini-2.0-flash"    # cheap model for compilation
    token_budget: int = 400
    max_feedback_examples: int = 3
    auto_approve_confidence: float = 0.95
    ab_test_size: int = 200
    ab_lift_threshold: float = 5.0
    discovery_interval: int = 50
    predefined_strategies: list = field(default_factory=list)
