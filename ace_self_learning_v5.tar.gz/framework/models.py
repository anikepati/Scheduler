"""Data models."""
from pydantic import BaseModel, Field
from typing import Optional, Any
from enum import Enum
from datetime import datetime
import uuid

def _uid(): return str(uuid.uuid4())

class FeedbackAction(str, Enum):
    APPROVE = "approve"
    REJECT = "reject"
    CORRECT = "correct"

class PatternStatus(str, Enum):
    CANDIDATE = "candidate"
    PROBATION = "probation"
    ACTIVE = "active"
    DEPRECATED = "deprecated"

class ReasoningStep(BaseModel):
    step_id: str
    action: str
    input_data: Any = None
    reasoning: str = ""
    conclusion: str = ""
    confidence: float = 0.0

class ChainRecord(BaseModel):
    id: str = Field(default_factory=_uid)
    use_case_id: str
    question_type: str
    question_text: str
    question_data: dict = {}
    reasoning_chain: list[ReasoningStep] = []
    answer: str = ""
    rationale: str = ""
    score: int = 0
    covered: list[str] = []
    missed: list[str] = []
    layer: str = "L3"
    activated_harness: list[str] = []  # which harness artifacts were activated
    harness_followed: bool = False     # did agent follow the strategy?
    validator_results: list[dict] = []
    user_action: Optional[FeedbackAction] = None
    user_correction: str = ""
    correction_target_step: str = ""
    cluster_id: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ReasoningStrategy(BaseModel):
    question_type: str
    version: int = 1
    thinking_steps: list[str] = []
    errors_to_avoid: list[dict] = []
    good_examples: list[dict] = []
    constraints: list[str] = []
    compiled_from_count: int = 0

class ValidatorRule(BaseModel):
    id: str
    step_id: str = ""
    check_type: str  # fact | logic | reasoning | consistency
    condition: str = ""
    expected: Any = None
    must_contain: list[str] = []
    confidence: float = 0.5
    active: bool = True

class TreeRule(BaseModel):
    id: str
    condition: str
    conclusion: str
    rationale_template: str = ""
    confidence: float = 0.0
    edge_cases: list[dict] = []

class Pattern(BaseModel):
    id: str = Field(default_factory=_uid)
    use_case_id: str
    cluster_id: str = ""
    description: str
    evidence_count: int = 0
    status: PatternStatus = PatternStatus.CANDIDATE
    ab_treatment: list[int] = []
    ab_control: list[int] = []

class FeedbackInput(BaseModel):
    chain_id: str
    action: FeedbackAction
    correction: str = ""
    correction_target_step: str = ""
