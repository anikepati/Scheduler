"""Background agents: PatternDiscovery + Governance."""
import json, logging
from typing import AsyncGenerator
from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types as genai_types
from google.genai import Client as GenaiClient
from framework.config import DomainConfig
from framework.models import Pattern, PatternStatus
from framework import db

logger = logging.getLogger(__name__)

class PatternDiscoveryAgent(BaseAgent):
    """Uses CHEAP evolver model (paper: harness-updating is flat)."""
    config: DomainConfig
    class Config:
        arbitrary_types_allowed = True

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[genai_types.Content, None]:
        cfg = self.config
        await db.init_pool(cfg.db_url)
        clusters = await db.get_clusters_for_discovery(cfg.use_case_id)
        if not clusters:
            yield genai_types.Content(role="model", parts=[genai_types.Part(text="No clusters.")])
            return
        total = 0
        for cl in clusters:
            corrections = await db.get_cluster_corrections(cl["id"])
            if len(corrections) < 3: continue
            texts = "\n".join(f"- {c['user_correction'][:120]}" for c in corrections[:10])
            try:
                r = GenaiClient().models.generate_content(model=cfg.evolver_model,
                    contents=f"Find recurring reasoning errors:\n{texts}\n\nJSON: {{\"patterns\":[{{\"description\":\"...\",\"evidence_count\":N}}]}}",
                    config=genai_types.GenerateContentConfig(temperature=0.1, max_output_tokens=512))
                t = r.text.strip()
                if t.startswith("```"): t = t.split("\n",1)[1].rsplit("```",1)[0].strip()
                for p in json.loads(t).get("patterns",[]):
                    if p.get("evidence_count",0) < 3: continue
                    await db.save_pattern(Pattern(use_case_id=cfg.use_case_id, cluster_id=cl["id"],
                        description=p["description"], evidence_count=p.get("evidence_count",3), status=PatternStatus.PROBATION))
                    total += 1
                await db.mark_analyzed(cl["id"])
            except Exception as e: logger.error(f"Discovery: {e}")
        yield genai_types.Content(role="model", parts=[genai_types.Part(text=f"Found {total} patterns.")])

class GovernanceAgent(BaseAgent):
    """A/B test evaluation + health monitoring."""
    config: DomainConfig
    class Config:
        arbitrary_types_allowed = True

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[genai_types.Content, None]:
        cfg = self.config
        await db.init_pool(cfg.db_url)
        actions = []
        for pat in await db.get_probation_patterns(cfg.use_case_id):
            t = pat["ab_treatment"]; c = pat["ab_control"]
            if isinstance(t,str): t = json.loads(t)
            if isinstance(c,str): c = json.loads(c)
            h = cfg.ab_test_size // 2
            if len(t) < h or len(c) < h: continue
            lift = (sum(t)/len(t)) - (sum(c)/len(c))
            if lift >= cfg.ab_lift_threshold:
                await db.set_pattern_status(pat["id"], cfg.use_case_id, "active", f"+{lift:.1f}%")
                actions.append(f"PROMOTED {pat['id'][:8]}: +{lift:.1f}%")
            else:
                await db.set_pattern_status(pat["id"], cfg.use_case_id, "deprecated", f"{lift:.1f}%")
                actions.append(f"DEPRECATED {pat['id'][:8]}")
        yield genai_types.Content(role="model", parts=[genai_types.Part(text="\n".join(actions) if actions else "No actions.")])
