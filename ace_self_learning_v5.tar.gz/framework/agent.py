"""
SelfLearningAgent(BaseAgent) v4 — with harness activation + compliance verification.

Paper insights (arXiv:2605.30621):
  1. Evolver can be cheap (harness-updating is flat) → use cheap model for compilation
  2. Harness ACTIVATION is the bottleneck → explicit activation step
  3. Harness FOLLOWING must be verified → compliance check after generation

Pipeline:
  1. Load harness (tree rules + validators + reasoning strategy)
  2. ACTIVATE: identify which harness artifacts apply to THIS question
  3. Try L1 (decision tree) → deterministic, instant
  4. L2: build prompt with ACTIVATED strategy + validator constraints
  5. Call LLM (strong solver model)
  6. Validate reasoning chain
  7. VERIFY COMPLIANCE: did agent follow the activated strategy?
  8. Re-prompt if validation or compliance fails
  9. Save chain with activation + compliance metadata
"""
import json, logging
from typing import AsyncGenerator
from google.adk.agents import BaseAgent
from google.adk.agents.invocation_context import InvocationContext
from google.genai import types as genai_types
from google.genai import Client as GenaiClient
from framework.config import DomainConfig
from framework.models import ChainRecord, ReasoningStep
from framework.validators import run_validators, all_pass, get_constraints
from framework.learning import assign_cluster
from framework import db

logger = logging.getLogger(__name__)

STRUCTURED_OUTPUT = """Respond with JSON only:
{"reasoning_chain":[{"step_id":"step_1","action":"what checking","reasoning":"analysis","conclusion":"result"}],
"answer":"final answer","rationale":"full explanation for investigator"}"""


class SelfLearningAgent(BaseAgent):
    """Self-learning agent with harness activation and compliance verification."""
    config: DomainConfig
    _ready: bool = False

    class Config:
        arbitrary_types_allowed = True

    async def _init(self):
        if not self._ready:
            await db.init_pool(self.config.db_url)
            await db.init_tables()
            for s in self.config.predefined_strategies:
                from framework.models import ReasoningStrategy
                await db.save_strategy(self.config.use_case_id, s.get("question_type",""),
                    ReasoningStrategy(question_type=s.get("question_type",""),
                        thinking_steps=s.get("thinking_steps",[]),
                        errors_to_avoid=s.get("errors_to_avoid",[])))
            self._ready = True

    async def _run_async_impl(self, ctx: InvocationContext) -> AsyncGenerator[genai_types.Content, None]:
        await self._init()
        state, cfg = ctx.session.state, self.config
        qid = state.get("question_id","")
        qtype = state.get("question_type", qid)
        qtext = state.get("user_question","")
        qdata = _pj(state.get("question_data","{}"))
        facts = _pj(state.get("key_facts","[]"))

        # ── Step 1: Load harness ──
        tree_rules = await db.get_tree_rules(cfg.use_case_id, qtype)
        strategy = await db.get_strategy(cfg.use_case_id, qtype)
        validators = await db.get_validators(cfg.use_case_id, qtype)

        # ── Step 2: ACTIVATE — which harness artifacts apply? ──
        # (Paper: harness activation is the bottleneck for weaker models)
        activated = []
        if tree_rules: activated.append(f"tree_rules:{len(tree_rules)}")
        if strategy: activated.append(f"strategy:v{strategy.get('version',1)}")
        if validators: activated.append(f"validators:{len(validators)}")
        logger.info(f"[{self.name}] {qid}: activated harness = {activated}")

        # ── Step 3: Try L1 (decision tree) ──
        tree_result = _eval_tree(tree_rules, qdata)
        if tree_result and tree_result["confidence"] >= cfg.auto_approve_confidence:
            v_results = await run_validators(cfg.use_case_id, qtype, qdata, [], tree_result["answer"])
            if all_pass(v_results):
                chain = ChainRecord(use_case_id=cfg.use_case_id, question_type=qtype,
                    question_text=qtext, question_data=qdata,
                    answer=tree_result["answer"], rationale=tree_result["rationale"],
                    score=100, layer="L1", activated_harness=activated, harness_followed=True,
                    validator_results=[r.to_dict() for r in v_results])
                await db.save_chain(chain); await assign_cluster(chain)
                state["chain_id"] = chain.id
                logger.info(f"[{self.name}] {qid}: L1 deterministic")
                yield genai_types.Content(role="model", parts=[genai_types.Part(
                    text=f"{tree_result['rationale']}\n\n[L1 | Chain: {chain.id[:8]}]")])
                return

        # ── Step 4: Build prompt with ACTIVATED harness ──
        layer = "L2" if strategy else "L3"
        strategy_text = _build_strategy(strategy) if strategy else ""
        constraint_text = _build_constraints(validators) if validators else ""

        sys_prompt = f"{cfg.system_instruction}\n\n{strategy_text}\n\n{STRUCTURED_OUTPUT}"
        prompt = f"{qtext}\n\nData: {json.dumps(qdata)[:500]}{constraint_text}"

        # ── Step 5: Call LLM (strong solver model — paper: invest here) ──
        client = GenaiClient()
        answer, rationale, steps = "", "", []
        try:
            resp = client.models.generate_content(model=cfg.solver_model, contents=prompt,
                config=genai_types.GenerateContentConfig(system_instruction=sys_prompt,
                    max_output_tokens=1500, temperature=0.2))
            parsed = _parse(resp.text or "")
            answer = parsed.get("answer", resp.text or "")
            rationale = parsed.get("rationale","")
            steps = [ReasoningStep(**s) for s in parsed.get("reasoning_chain",[])]
        except Exception as e:
            answer = f"Error: {e}"

        # ── Step 6: Validate reasoning chain ──
        v_results = await run_validators(cfg.use_case_id, qtype, qdata,
            [s.model_dump() for s in steps], answer)
        failed = get_constraints(v_results)

        # ── Step 7: VERIFY COMPLIANCE — did agent follow the strategy? ──
        # (Paper: activation without following = wasted harness)
        harness_followed = _check_compliance(strategy, steps, answer) if strategy else False

        # ── Step 8: Re-prompt if validation or compliance fails ──
        if (failed or (strategy and not harness_followed)) and layer == "L2":
            retry_parts = []
            if failed: retry_parts.append("FAILED CHECKS:\n" + "\n".join(failed))
            if not harness_followed:
                retry_parts.append("You did NOT follow the thinking protocol. Follow EACH step explicitly.")
            try:
                resp2 = client.models.generate_content(model=cfg.solver_model,
                    contents=f"{prompt}\n\n" + "\n".join(retry_parts),
                    config=genai_types.GenerateContentConfig(system_instruction=sys_prompt,
                        max_output_tokens=1500, temperature=0.1))
                p2 = _parse(resp2.text or "")
                answer = p2.get("answer", resp2.text or "")
                rationale = p2.get("rationale","")
                steps = [ReasoningStep(**s) for s in p2.get("reasoning_chain",[])]
                v_results = await run_validators(cfg.use_case_id, qtype, qdata,
                    [s.model_dump() for s in steps], answer)
                harness_followed = _check_compliance(strategy, steps, answer) if strategy else False
            except Exception: pass

        # ── Score ──
        sr = _score(answer, facts)

        # ── Step 9: Save chain with activation + compliance ──
        chain = ChainRecord(use_case_id=cfg.use_case_id, question_type=qtype,
            question_text=qtext, question_data=qdata, reasoning_chain=steps,
            answer=answer, rationale=rationale, score=sr["score"],
            covered=sr["covered"], missed=sr["missed"], layer=layer,
            activated_harness=activated, harness_followed=harness_followed,
            validator_results=[r.to_dict() for r in v_results])
        try: await db.save_chain(chain); await assign_cluster(chain)
        except Exception as e: logger.error(f"Save: {e}")

        state["chain_id"] = chain.id
        hf = "followed" if harness_followed else "not followed"
        logger.info(f"[{self.name}] {qid}: {layer} score={sr['score']}% harness={hf}")

        yield genai_types.Content(role="model", parts=[genai_types.Part(
            text=f"{rationale or answer}\n\n[{layer} | Score: {sr['score']}% | Harness: {hf} | Chain: {chain.id[:8]}]")])


def _eval_tree(rules, data):
    for r in rules:
        try:
            if eval(r["condition"], {"data": type("D",(),data)(), "__builtins__": {}}):
                rat = r.get("rationale_template", r["conclusion"])
                for k,v in data.items(): rat = rat.replace(f"${{data.{k}}}", str(v))
                return {"answer": r["conclusion"], "rationale": rat, "confidence": r.get("confidence",0.5)}
        except: continue
    return None

def _build_strategy(s):
    parts = []
    steps = s.get("thinking_steps")
    if isinstance(steps, str): steps = json.loads(steps)
    if steps:
        parts.append("THINKING PROTOCOL (you MUST follow each step):")
        for i, st in enumerate(steps or [], 1): parts.append(f"  {i}. {st}")
    errors = s.get("errors_to_avoid")
    if isinstance(errors, str): errors = json.loads(errors)
    if errors:
        parts.append("\nERRORS TO AVOID:")
        for e in (errors or [])[:5]: parts.append(f"  X {e.get('error','')} -> {e.get('fix','')}")
    examples = s.get("good_examples")
    if isinstance(examples, str): examples = json.loads(examples)
    if examples:
        parts.append("\nGOOD REASONING EXAMPLE:")
        for ex in (examples or [])[:2]:
            parts.append(f"  Q: {ex.get('question','')[:80]}")
            parts.append(f"  R: {ex.get('reasoning','')[:200]}")
    return "\n".join(parts) if parts else ""

def _build_constraints(validators):
    mc_all = []
    for v in validators:
        mc = v.get("must_contain")
        if isinstance(mc, str): mc = json.loads(mc)
        if mc: mc_all.extend(mc)
    if mc_all:
        return "\n\nHARD CONSTRAINTS: answer MUST mention: " + ", ".join(set(mc_all))
    return ""

def _check_compliance(strategy, steps, answer):
    """Paper finding: verify agent actually FOLLOWED the strategy."""
    if not strategy: return False
    ts = strategy.get("thinking_steps")
    if isinstance(ts, str): ts = json.loads(ts)
    if not ts: return True
    # Check: does each thinking step appear in the reasoning chain?
    all_reasoning = " ".join(s.reasoning.lower() for s in steps) + " " + answer.lower()
    matched = 0
    for step in (ts or []):
        keywords = [w for w in step.lower().split() if len(w) > 4][:3]
        if any(k in all_reasoning for k in keywords): matched += 1
    return matched >= len(ts) * 0.6  # at least 60% of thinking steps followed

def _parse(raw):
    t = raw.strip()
    if t.startswith("```"): t = t.split("\n",1)[1].rsplit("```",1)[0].strip()
    try: return json.loads(t)
    except: return {"answer": raw, "rationale": raw, "reasoning_chain": []}

def _score(answer, facts):
    low = answer.lower()
    c = [f for f in facts if any(w in low for w in f.lower().split() if len(w) > 3)]
    m = [f for f in facts if f not in c]
    return {"score": round(len(c)/max(1,len(facts))*100), "covered": c, "missed": m}

def _pj(v):
    if isinstance(v, str):
        try: return json.loads(v)
        except: return v
    return v
