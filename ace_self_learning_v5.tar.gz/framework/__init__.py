"""ACE Self-Learning Framework v4 — harness evolution (arXiv:2605.30621)"""
