"""EDR QA domain config with predefined reasoning strategies."""
from framework.config import DomainConfig

def create_config(db_url="postgresql://localhost:5432/ace_learning"):
    return DomainConfig(
        use_case_id="edr_qa", name="EDR QA",
        system_instruction="You are an Actimize EDR/RRO QA expert. Reason step-by-step about alert triggers, filing requirements, and compliance procedures.",
        db_url=db_url, solver_model="gemini-2.5-flash", evolver_model="gemini-2.0-flash",
        predefined_strategies=[
            {"question_type":"wire_alert","thinking_steps":["Check amount against $50K threshold","Check prior wires in 90-day lookback","Check beneficiary approval status","Apply AND logic across all conditions","Consider edge cases and logging requirements"],
             "errors_to_avoid":[{"error":"Alerting when only one condition met","fix":"All THREE must be met (AND logic)","frequency":0}]},
            {"question_type":"ctr_aggregation","thinking_steps":["Identify window type (rolling 24hr vs calendar)","Sum all cash transactions","Compare against $10K threshold","Check for structuring patterns"],
             "errors_to_avoid":[{"error":"Using calendar day instead of rolling window","fix":"EDR uses rolling 24hr to catch midnight structuring","frequency":0}]},
            {"question_type":"pep_screening","thinking_steps":["Note fuzzy match score","Compare against 0.85 threshold","Check override rules (surname-override)","Determine log vs escalate"],
             "errors_to_avoid":[{"error":"Ignoring surname-override","fix":"Exact surname + partial first = escalate even below 0.85","frequency":0}]},
        ])
