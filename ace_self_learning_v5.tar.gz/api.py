"""FastAPI — feedback, explain, metrics, strategy, validators, tree, events."""
from fastapi import FastAPI, HTTPException
from framework.models import FeedbackInput
from framework.learning import process_feedback
from framework import db

def create_app(cfg):
    app = FastAPI(title="ACE Self-Learning Agent v4", version="4.0")
    @app.on_event("startup")
    async def start(): await db.init_pool(cfg.db_url); await db.init_tables()

    @app.post("/api/feedback")
    async def feedback(req: FeedbackInput):
        ch = await db.get_chain(req.chain_id)
        if not ch: raise HTTPException(404)
        await process_feedback(req.chain_id, req.action.value, req.correction,
            req.correction_target_step, cfg.use_case_id, cfg.evolver_model)
        return {"status": "ok"}

    @app.get("/api/explain/{cid}")
    async def explain(cid: str):
        ch = await db.get_chain(cid)
        if not ch: raise HTTPException(404)
        qt = ch.get("question_type","")
        return {"chain": ch, "strategy": await db.get_strategy(cfg.use_case_id, qt),
                "validators": await db.get_validators(cfg.use_case_id, qt),
                "tree_rules": await db.get_tree_rules(cfg.use_case_id, qt)}

    @app.get("/api/metrics/{uc_id}")
    async def metrics(uc_id: str): return await db.get_metrics(uc_id)

    @app.get("/api/strategy/{qt}")
    async def strategy(qt: str): return await db.get_strategy(cfg.use_case_id, qt)

    @app.get("/api/validators/{qt}")
    async def validators(qt: str): return await db.get_validators(cfg.use_case_id, qt)

    @app.get("/api/tree/{qt}")
    async def tree(qt: str): return await db.get_tree_rules(cfg.use_case_id, qt)

    @app.get("/api/events/{uc_id}")
    async def events(uc_id: str):
        p = await db.pool()
        async with p.acquire() as c:
            rows = await c.fetch("SELECT * FROM events WHERE use_case_id=$1 ORDER BY created_at DESC LIMIT 50", uc_id)
        return [dict(r) for r in rows]

    return app
